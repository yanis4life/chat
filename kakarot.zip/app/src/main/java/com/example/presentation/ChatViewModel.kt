package com.example.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.RetrofitClient
import com.example.domain.Message
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel : ViewModel() {
    val supportedModels = listOf(
        "gemini3.1pro", "gpt54", "gpt55",
        "kimik26instant", "claude47opus", "claude46sonnet", "nano banana"
    )

    private val _selectedModel = MutableStateFlow(supportedModels.first())
    val selectedModel = _selectedModel.asStateFlow()

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    fun selectModel(model: String) {
        _selectedModel.value = model
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        val userMessage = Message(UUID.randomUUID().toString(), text, true)
        _messages.value = _messages.value + userMessage

        viewModelScope.launch {
            _isLoading.value = true
            try {
                if (_selectedModel.value == "nano banana") {
                    val imageUrl = com.example.api.NanoBananaApi.generateImage(text)
                    if (imageUrl != null) {
                        val aiMessage = Message(UUID.randomUUID().toString(), imageUrl, false, isImage = true)
                        _messages.value = _messages.value + aiMessage
                    } else {
                        val aiMessage = Message(UUID.randomUUID().toString(), "Failed to generate image via Nano Banana.", false)
                        _messages.value = _messages.value + aiMessage
                    }
                } else {
                    val responseBody = RetrofitClient.apiService.getChat(
                        model = _selectedModel.value,
                        question = text
                    )
                    
                    val replyText = responseBody.string()
                    val answer = try {
                        val json = org.json.JSONObject(replyText)
                        if (json.has("answer")) json.optString("answer", replyText) else replyText
                    } catch (e: Exception) {
                        replyText
                    }
                    val aiMessage = Message(java.util.UUID.randomUUID().toString(), answer, false)
                    _messages.value = _messages.value + aiMessage
                }
                
            } catch (e: Exception) {
                val errorMessage = Message(UUID.randomUUID().toString(), "Error sending message: ${e.localizedMessage}", false)
                _messages.value = _messages.value + errorMessage
            } finally {
                _isLoading.value = false
            }
        }
    }
}

package com.example.presentation

import androidx.lifecycle.ViewModel
import com.example.domain.UserModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class AuthViewModel : ViewModel() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance().getReference("users") }

    private val _user = MutableStateFlow<UserModel?>(null)
    val user = _user.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()

    init {
        checkCurrentUser()
    }

    private fun checkCurrentUser() {
        try {
            val currentUser = auth.currentUser
            if (currentUser != null) {
                fetchUserProfile(currentUser.uid, currentUser.email ?: "")
            }
        } catch (e: Exception) {
            _error.value = "Firebase not fully configured. Please add google-services.json."
        }
    }

    private fun fetchUserProfile(uid: String, email: String) {
        db.child(uid).get().addOnSuccessListener { snapshot ->
            val internalId = snapshot.child("internal_id").getValue(Int::class.java) ?: 0
            val isAdmin = internalId == 1
            
            _user.value = UserModel(
                uid = uid,
                email = email,
                internalId = internalId,
                isAdmin = isAdmin
            )
        }.addOnFailureListener {
            _user.value = UserModel(uid = uid, email = email, isAdmin = false)
        }
    }

    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _error.value = "Fields cannot be empty"
            return
        }
        _isLoading.value = true
        _error.value = null
        auth.signInWithEmailAndPassword(email, pass).addOnSuccessListener { result ->
            result.user?.let { fetchUserProfile(it.uid, it.email ?: "") }
            _isLoading.value = false
        }.addOnFailureListener { e ->
            _error.value = e.localizedMessage
            _isLoading.value = false
        }
    }

    fun register(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _error.value = "Fields cannot be empty"
            return
        }
        _isLoading.value = true
        _error.value = null
        auth.createUserWithEmailAndPassword(email, pass).addOnSuccessListener { result ->
            result.user?.let { u ->
                db.child(u.uid).child("internal_id").setValue(0).addOnCompleteListener {
                    fetchUserProfile(u.uid, u.email ?: "")
                    _isLoading.value = false
                }
            }
        }.addOnFailureListener { e ->
            _error.value = e.localizedMessage
            _isLoading.value = false
        }
    }

    fun logout() {
        auth.signOut()
        _user.value = null
    }
}


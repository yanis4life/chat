package com.example.presentation

import androidx.lifecycle.ViewModel
import com.example.BuildConfig
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel : ViewModel() {
    private val _isUpdateRequired = MutableStateFlow(false)
    val isUpdateRequired = _isUpdateRequired.asStateFlow()

    private val _updateUrl = MutableStateFlow("")
    val updateUrl = _updateUrl.asStateFlow()

    private val _isDarkTheme = MutableStateFlow<Boolean?>(null)
    val isDarkTheme = _isDarkTheme.asStateFlow()

    init {
        checkForUpdates()
    }

    fun toggleTheme(systemDark: Boolean) {
        _isDarkTheme.value = !(_isDarkTheme.value ?: systemDark)
    }

    private fun checkForUpdates() {
        val database = try {
            FirebaseDatabase.getInstance()
        } catch (e: Exception) {
            // Firebase may not be initialized if google-services.json is missing
            return
        }
        val configRef = database.getReference("app_config")

        configRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val latestVersionCode = snapshot.child("latest_version_code").getValue(Int::class.java) ?: return
                val url = snapshot.child("update_url").getValue(String::class.java) ?: return

                val currentVersionCode = BuildConfig.VERSION_CODE

                if (latestVersionCode > currentVersionCode) {
                    _updateUrl.value = url
                    _isUpdateRequired.value = true
                } else {
                    _isUpdateRequired.value = false
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // handle error
            }
        })
    }
}

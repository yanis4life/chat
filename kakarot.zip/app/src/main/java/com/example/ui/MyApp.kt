package com.example.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.presentation.AuthViewModel
import com.example.presentation.ChatViewModel
import com.example.presentation.MainViewModel

@Composable
fun MyApp(mainViewModel: MainViewModel = viewModel()) {
    val authViewModel: AuthViewModel = viewModel()
    val chatViewModel: ChatViewModel = viewModel()

    val isUpdateRequired by mainViewModel.isUpdateRequired.collectAsState()
    val updateUrl by mainViewModel.updateUrl.collectAsState()
    val user by authViewModel.user.collectAsState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        if (isUpdateRequired) {
            UpdateRequiredDialog(updateUrl = updateUrl)
        } else {
            if (user == null) {
                AuthScreen(viewModel = authViewModel)
            } else {
                ChatScreen(
                    authViewModel = authViewModel,
                    chatViewModel = chatViewModel,
                    mainViewModel = mainViewModel
                )
            }
        }
    }
}

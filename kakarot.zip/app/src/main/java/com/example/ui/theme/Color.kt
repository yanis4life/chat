package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SleekPrimary = Color(0xFF0061A4)
val SleekOnPrimary = Color.White
val SleekPrimaryContainer = Color(0xFFD1E4FF)
val SleekOnPrimaryContainer = Color(0xFF001D35)

val SleekSecondaryContainer = Color(0xFFF3F3F7)
val SleekOnSecondaryContainer = Color(0xFF1A1C1E)

val SleekBackground = Color(0xFFFDFBFF)
val SleekOnBackground = Color(0xFF1A1C1E)

val SleekSurface = Color.White
val SleekOnSurface = Color(0xFF1A1C1E)
val SleekSurfaceVariant = Color(0xFFF3F3F7)
val SleekOnSurfaceVariant = Color(0xFF44474E)
val SleekOutline = Color(0xFFC4C7CF)

val AdminBadgeContainer = Color(0xFFEADDFF)
val AdminBadgeContent = Color(0xFF21005D)
val AdminBadgeOutline = Color(0xFFD0BCFF)

val SuccessGreen = Color(0xFF34A853)
val NightBlue = Color(0xFF0F172A)
val NightBlueVariant = Color(0xFF1E293B)
val NightGray = Color(0xFF334155)
val NightOnGray = Color(0xFFCBD5E1)
val NightOutline = Color(0xFF475569)

package com.example.domain

data class Message(
    val id: String,
    val text: String,
    val isFromUser: Boolean,
    val isImage: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

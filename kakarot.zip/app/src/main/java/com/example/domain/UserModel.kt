package com.example.domain

data class UserModel(
    val uid: String = "",
    val email: String = "",
    val internalId: Int = 0,
    val isAdmin: Boolean = false
)

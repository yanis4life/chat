package com.example.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object NanoBananaApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private val ANGLES = listOf("front", "side", "high angle", "low angle", "close up")
    private val LIGHTS = listOf("natural", "studio", "neon", "cinematic", "soft")
    private val MOODS = listOf("dark", "bright", "dramatic", "peaceful", "cyberpunk")
    private val FILTERS = listOf("35mm", "polaroid", "vhs", "black and white", "vibrant")
    private val CAMERAS = listOf("dslr", "drone", "gopro", "vintage", "smartphone")

    private fun enhancePrompt(prompt: String): String {
        val angle = ANGLES.random()
        val light = LIGHTS.random()
        val mood = MOODS.random()
        val film = FILTERS.random()
        val camera = CAMERAS.random()
        val quality = listOf(8, 12, 16).random()
        return "$prompt, $angle view, $light lighting, $mood atmosphere, $film film, $camera camera, ultra hd ${quality}k, masterpiece"
    }

    private fun sha256Hex16(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(input.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }.take(16)
    }

    private fun base64Encode(input: String): String {
        return Base64.getEncoder().encodeToString(input.toByteArray())
    }

    private suspend fun getPhotoroomToken(): String? = withContext(Dispatchers.IO) {
        try {
            val jsonBody = JSONObject().put("clientType", "CLIENT_TYPE_ANDROID").toString()
            val request = Request.Builder()
                .url("https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=AIzaSyAJGrgbFGB_-h8V2oJLr4b-_ipetqM0duU")
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .addHeader("Content-Type", "application/json")
                .addHeader("X-Android-Package", "com.photoroom.app")
                .addHeader("X-Android-Cert", "0424A4898A4B33940D8BF16E44251B876E97F8D0")
                .addHeader("User-Agent", "Dalvik/2.1.0 (Linux; U; Android 12)")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val respBody = response.body?.string() ?: return@withContext null
                JSONObject(respBody).getString("idToken")
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun generateImage(prompt: String): String? = withContext(Dispatchers.IO) {
        try {
            val token = getPhotoroomToken() ?: return@withContext null
            val requestId = sha256Hex16("${System.currentTimeMillis()}${Random.nextDouble()}${prompt.take(10)}")

            val payload = JSONObject().apply {
                put("userPrompt", enhancePrompt(prompt))
                put("appId", "expert")
                put("styleId", "realistic")
                put("sizeId", "SQUARE_HD")
                put("numberOfImages", 1)
                put("cfgScale", 9)
                put("steps", 45)
                put("sampler", "dpmpp_2m_karras")
                put("seed", Random.nextInt(1, 999999999))
                put("clip_skip", 2)
                put("hires_fix", true)
                put("denoising", 0.75)
                put("face_restore", true)
                put("upscale", 2)
            }

            val request = Request.Builder()
                .url("https://serverless-api.photoroom.com/v2/ai-tools/generate-images")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .addHeader("Host", "serverless-api.photoroom.com")
                .addHeader("Accept", "text/event-stream")
                .addHeader("Authorization", token)
                .addHeader("Content-Type", "application/json")
                .addHeader("User-Agent", "okhttp/4.12.0")
                .addHeader("Pr-App-Version", "2025.47.03 (2180)")
                .addHeader("Pr-Platform", "android")
                .addHeader("X-Request-ID", requestId)
                .addHeader("X-Enhanced", base64Encode("true"))
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext null

            val source = java.io.BufferedReader(response.body?.charStream())
            var imageUrl: String? = null
            source.forEachLine { line ->
                if (line.contains("\"eventType\":\"aiImageResult\"")) {
                    val searchString = "\"imageUrl\":\""
                    val start = line.indexOf(searchString)
                    if (start != -1) {
                        val urlStart = start + searchString.length
                        val end = line.indexOf("\"", urlStart)
                        if (end != -1) {
                            imageUrl = line.substring(urlStart, end)
                        }
                    }
                }
            }
            imageUrl
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

package com.example.api

import okhttp3.ResponseBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @FormUrlEncoded
    @POST("api.php")
    suspend fun postChat(
        @Field("model") model: String,
        @Field("question") question: String
    ): ResponseBody

    @GET("api.php")
    suspend fun getChat(
        @Query("model") model: String,
        @Query("question") question: String
    ): ResponseBody
}
